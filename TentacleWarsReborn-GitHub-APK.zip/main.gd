extends Node2D
# First playable vertical slice: procedural relaxed levels and a persistent evolution map.
const SAVE := "user://reborn.json"
const BG := Color("0b1724")
const CYAN := Color("64d8e7")
const RED := Color("f17891")
const NEUTRAL := Color("b2b7bf")
var rng := RandomNumberGenerator.new()
var mode := "menu"
var level := 1
var sector := 1
var dna := 0
var power := 0
var speed := 0
var nodes: Array[Dictionary] = []
var edges: Array[Vector2i] = []
var walls: Array[Rect2] = []
var selected := -1
var dragging := -1
var enemy_clock := 0.0
var spawn_clock := 0.0
var message := ""
var font: Font

func _ready() -> void:
 rng.randomize()
 font = ThemeDB.fallback_font
 load_game()
 set_process(true)
 queue_redraw()

func load_game() -> void:
 if FileAccess.file_exists(SAVE):
  var v = JSON.parse_string(FileAccess.get_file_as_string(SAVE))
  if v is Dictionary:
   dna = int(v.get("dna", 0)); power = int(v.get("power", 0)); speed = int(v.get("speed", 0)); sector = int(v.get("sector", 1))

func save_game() -> void:
 var f := FileAccess.open(SAVE, FileAccess.WRITE)
 f.store_string(JSON.stringify({"dna":dna,"power":power,"speed":speed,"sector":sector}))

func label_text(s: String, p: Vector2, size: int = 36, color: Color = Color.WHITE) -> void:
 draw_string(font, p, s, HORIZONTAL_ALIGNMENT_CENTER, -1, size, color)

func button(s: String, y: float, tint: Color = CYAN) -> void:
 draw_rect(Rect2(125,y,830,104), Color(tint,0.15),true)
 draw_rect(Rect2(125,y,830,104),tint,false,3)
 label_text(s,Vector2(540,y+68),39)

func _draw() -> void:
 draw_rect(Rect2(Vector2.ZERO,Vector2(1080,1920)),BG)
 for i in 24:
  var p := Vector2(float(i*193%1080),float(i*337%1920))
  draw_circle(p,2,Color(CYAN,0.11))
 label_text("TENTACLE WARS",Vector2(540,120),65,CYAN)
 if mode == "menu":
  label_text("REBORN  •  PROTOTYPE",Vector2(540,180),30,NEUTRAL)
  button("БЕСКОНЕЧНЫЕ УРОВНИ",470)
  button("ЭВОЛЮЦИЯ",620)
  label_text("Захватывай клетки, проводя связи",Vector2(540,850),29,NEUTRAL)
  label_text("Перетяни от своей клетки к цели",Vector2(540,900),29,NEUTRAL)
  label_text("ДНК: %d    Сектор: %d" % [dna,sector],Vector2(540,1050),32)
  return
 label_text(("УРОВЕНЬ %d" % level) if mode == "endless" else ("ЭВОЛЮЦИЯ  •  СЕКТОР %d" % sector),Vector2(540,192),39)
 for w in walls:
  draw_rect(w,Color("344b60"),true)
  draw_rect(w,Color("7e9bb0"),false,3)
 for e in edges:
  if e.x >= nodes.size() or e.y >= nodes.size(): continue
  var a: Dictionary = nodes[e.x]; var b: Dictionary = nodes[e.y]
  var tint: Color = CYAN if a.owner == 1 else RED
  draw_line(a.pos,b.pos,Color(tint,0.22),24,true)
  draw_line(a.pos,b.pos,tint,6,true)
 for i in nodes.size():
  var n: Dictionary = nodes[i]
  var c: Color = CYAN if n.owner == 1 else (RED if n.owner == 2 else NEUTRAL)
  var r: float = n.radius
  draw_circle(n.pos,r+12,Color(c,0.14))
  draw_circle(n.pos,r,Color(c,0.34))
  draw_arc(n.pos,r,0,TAU,64,c,5,true)
  if i == dragging: draw_arc(n.pos,r+10,0,TAU,64,Color.WHITE,4,true)
  label_text(str(int(n.hp)),n.pos+Vector2(0,12),34)
 if dragging >= 0 and dragging < nodes.size():
  draw_line(nodes[dragging].pos,get_global_mouse_position(),Color(CYAN,0.7),5,true)
 if mode == "evolution":
  label_text("ДНК: %d   Сила: %d   Рост: %d" % [dna,power,speed],Vector2(540,1690),30)
  button("УЛУЧШИТЬ СИЛУ (%d ДНК)" % (3+power*3),1730,Color("7bbba5"))
 else:
  button("НОВАЯ КАРТА",1730,Color("7bbba5"))
 if message != "": label_text(message,Vector2(540,1590),31)
 draw_rect(Rect2(30,225,175,70),Color(CYAN,0.14),true)
 label_text("МЕНЮ",Vector2(118,273),28)

func start_level() -> void:
 nodes.clear(); edges.clear(); walls.clear(); dragging = -1; message = ""
 var count := rng.randi_range(6,9) if mode == "endless" else mini(7+int(sector/3),13)
 nodes.append({"pos":Vector2(160,970),"hp":85.0+power*8,"owner":1,"radius":62.0})
 nodes.append({"pos":Vector2(920,970),"hp":58.0+sector*2 if mode == "evolution" else 55.0,"owner":2,"radius":62.0})
 var attempts := 0
 while nodes.size() < count and attempts < 500:
  attempts += 1
  var p := Vector2(rng.randf_range(135,945),rng.randf_range(350,1500))
  var valid := true
  for n in nodes:
   if p.distance_to(n.pos) < 205: valid = false
  if valid: nodes.append({"pos":p,"hp":float(rng.randi_range(14,42)),"owner":0,"radius":float(rng.randi_range(43,59))})
 if mode == "endless" and rng.randf() < 0.65:
  walls.append(Rect2(Vector2(500,rng.randf_range(500,1150)),Vector2(48,190)))
 enemy_clock = 0; spawn_clock = 0
 queue_redraw()

func line_blocked(a: Vector2,b: Vector2) -> bool:
 for w in walls:
  if w.has_point(a) or w.has_point(b): return true
  for k in 24:
   if w.has_point(a.lerp(b,float(k)/23.0)): return true
 return false

func link_cells(a: int,b: int) -> void:
 if a == b or a < 0 or b < 0 or nodes[a].owner != 1: return
 if line_blocked(nodes[a].pos,nodes[b].pos): message = "ПУТЬ ПЕРЕКРЫТ"; return
 for e in edges:
  if e == Vector2i(a,b): return
 edges.append(Vector2i(a,b)); message = ""

func _process(delta: float) -> void:
 if mode == "menu": return
 spawn_clock += delta; enemy_clock += delta
 if spawn_clock >= 0.25:
  var tick := spawn_clock; spawn_clock = 0
  for i in nodes.size():
   if nodes[i].owner != 0:
    nodes[i].hp = minf(nodes[i].hp + tick*(2.5+speed if nodes[i].owner == 1 else 2.5),140.0)
  for e in edges:
   if e.x >= nodes.size() or e.y >= nodes.size(): continue
   var a: Dictionary = nodes[e.x]; var b: Dictionary = nodes[e.y]
   if a.owner == 0 or a.hp < 9: continue
   var amount := minf(a.hp-8,tick*(9+power*3 if a.owner == 1 else 8))
   a.hp -= amount
   if b.owner == a.owner: b.hp += amount
   else:
    b.hp -= amount
    if b.hp <= 0: b.owner = a.owner; b.hp = 7.0
  var player := false; var enemy := false
  for n in nodes:
   if n.owner == 1: player = true
   if n.owner == 2: enemy = true
  if not enemy:
   if mode == "endless": level += 1
   else: sector += 1; dna += 2 + int(sector/4); save_game()
   start_level(); message = "ПОБЕДА!"
  elif not player:
   start_level(); message = "ПОРАЖЕНИЕ — ПОВТОР"
 if enemy_clock > 3.0:
  enemy_clock = 0
  var from := -1; var target := -1; var dist := INF
  for i in nodes.size():
   if nodes[i].owner != 2: continue
   for j in nodes.size():
    if nodes[j].owner == 2 or line_blocked(nodes[i].pos,nodes[j].pos): continue
    var d: float = nodes[i].pos.distance_to(nodes[j].pos)
    if d < dist: dist = d; from = i; target = j
  if from >= 0:
   var exists := false
   for e in edges:
    if e == Vector2i(from,target): exists = true
   if not exists: edges.append(Vector2i(from,target))
 queue_redraw()

func node_at(p: Vector2) -> int:
 for i in nodes.size():
  if nodes[i].pos.distance_to(p) < nodes[i].radius+25: return i
 return -1

func _unhandled_input(event: InputEvent) -> void:
 if event is InputEventScreenTouch:
  var p: Vector2 = event.position
  if event.pressed:
   if mode == "menu":
    if p.y > 470 and p.y < 574: mode = "endless"; start_level()
    elif p.y > 620 and p.y < 724: mode = "evolution"; start_level()
   elif p.y > 225 and p.y < 305 and p.x < 220: mode = "menu"; save_game()
   elif p.y > 1730 and p.y < 1834:
    if mode == "endless": start_level()
    elif dna >= 3+power*3: dna -= 3+power*3; power += 1; save_game()
   else:
    var n := node_at(p)
    if n >= 0 and nodes[n].owner == 1: dragging = n
  else:
   if dragging >= 0: link_cells(dragging,node_at(p)); dragging = -1
  queue_redraw()
 elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
  var p := get_global_mouse_position()
  if event.pressed:
   if mode == "menu":
    if p.y > 470 and p.y < 574: mode = "endless"; start_level()
    elif p.y > 620 and p.y < 724: mode = "evolution"; start_level()
   elif p.y > 225 and p.y < 305 and p.x < 220: mode = "menu"; save_game()
   elif p.y > 1730 and p.y < 1834:
    if mode == "endless": start_level()
    elif dna >= 3+power*3: dna -= 3+power*3; power += 1; save_game()
   else:
    var n := node_at(p)
    if n >= 0 and nodes[n].owner == 1: dragging = n
  else:
   if dragging >= 0: link_cells(dragging,node_at(p)); dragging = -1
  queue_redraw()
