# Tentacle Wars Reborn — Android prototype

This is an **early, unverified Godot prototype**, not a finished remake. It includes a relaxed procedural mode and an early Evolution mode. No original commercial game assets are distributed here.

## Build APK (phone only)

1. Upload all files **and the `.github/workflows/build-android.yml` path** to the repository root (not inside an extra folder).
2. Open **Actions → Build Android APK → Run workflow**.
3. Open the finished workflow run and download **TentacleWarsReborn-debug-APK** from Artifacts.
4. Extract the ZIP downloaded from Actions and install the APK.

If the run fails, send the build log. Android export settings may need adjustment after the first cloud build. The debug APK uses a temporary signing key created per run, so updating an existing installation may require uninstalling it (which can erase saves); a persistent release signing key should be configured later.
